import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'prestashop.component.html'
})

export class PrestashopComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}