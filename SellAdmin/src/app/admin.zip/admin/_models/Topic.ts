export class Topic {
     topicID: string;
     topicName: string;
     topicDescription: string;
     topicStatus: number;
}
