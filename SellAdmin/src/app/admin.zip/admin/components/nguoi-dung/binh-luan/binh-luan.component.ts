import { Component, OnInit } from '@angular/core';

@Component ({
    templateUrl: 'binh-luan.component.html'
})

export class BinhLuanComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}
