export class RegisterKey {
    private key: string;
}
