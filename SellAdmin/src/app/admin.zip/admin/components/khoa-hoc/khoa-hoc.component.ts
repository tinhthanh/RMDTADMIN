import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: 'khoa-hoc.component.html'
})
export class KhoaHocComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
