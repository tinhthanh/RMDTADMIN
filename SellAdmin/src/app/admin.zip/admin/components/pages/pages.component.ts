import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'pages.component.html'
})

export class PagesComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}
