export class Comment {
        private commentID: string;
        private lessonID: string;
        private userID: string;
        private commentContent: string;
        private commentDate: any;
        private commentStatut: number;
}
