export class Role {
     roleID: number;
     roleName: string;
}
