import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'chu-de.component.html'
})

export class ChuDeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}