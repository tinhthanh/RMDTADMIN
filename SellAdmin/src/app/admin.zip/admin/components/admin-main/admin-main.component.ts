import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'admin-main.component.html'
})

export class AdminMainComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}
