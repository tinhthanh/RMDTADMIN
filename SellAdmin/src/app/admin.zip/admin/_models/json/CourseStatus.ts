export class CourseStatus {
    private courseID: string;
    private newStatus: number;
}
