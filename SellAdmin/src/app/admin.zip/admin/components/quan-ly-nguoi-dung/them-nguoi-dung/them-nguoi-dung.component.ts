import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'them-nguoi-dung.component.html'
})

export class ThemNguoiDungComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}