export class CourseType {
     courseTypeID: string;
     courseTitle: string;
    courseDescription: string;
}
