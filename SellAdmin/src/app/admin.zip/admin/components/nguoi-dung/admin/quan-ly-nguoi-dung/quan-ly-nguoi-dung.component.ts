import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'quan-ly-nguoi-dung.component.html'
})

export class QuanLyNguoiDungComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}
