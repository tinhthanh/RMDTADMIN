export class CourseUpdate {
    private courseID: string;
    private courseTitle: string;
    private courseDescription: string;
    private price: number;
    private courseTypeID: string;
    private topicID: string;
    private status: number;
    private courseAvatar: string;
    private courseDetail: string;
}
